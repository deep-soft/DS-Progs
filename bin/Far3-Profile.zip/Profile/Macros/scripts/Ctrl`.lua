Macro {
  area="Shell"; key="Ctrl`"; description="EMenu"; action = function()

  Keys('F11 E')

  end;
}
