Macro {
  area="Shell"; key="Left"; flags="EmptyCommandLine"; description="Lynx like left"; action = function()
    if (APanel.Bof) then
      Keys('CtrlPgUp')
    else
      Keys('Home')
    end
  end;
}

Macro {
  area="Shell"; key="Right"; flags="EmptyCommandLine"; description="Page down"; action = function()
    Keys('PgDn')
  end;
}
