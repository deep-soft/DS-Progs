Macro {
  description="Create a new folder with name consisting of the current date";
  area="Shell"; key="ShiftF7"; flags="NoPluginPanels";
  action=function()
  Folder = mf.date('%Y-%m0-%d')

  if (Panel.FExist(0,Folder)==0) then
    Keys('F7 CtrlY') print(Folder) Keys('Enter')
  else
    Panel.SetPos(0,Folder)
  end

  end;
}
