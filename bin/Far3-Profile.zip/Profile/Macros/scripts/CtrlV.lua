Macro {
  area="Shell"; key="CtrlV"; description="Change case of file"; action = function()

  Keys('F11 V Enter')

  end;
}
