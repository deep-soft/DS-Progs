Macro {
  area="Editor"; key="F3"; description="Exit from editor"; action = function()

  Keys('F4')
  end;
}

