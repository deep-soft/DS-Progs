Macro {
  description="Focus the current file from clipboard";
  area="Shell"; key="CtrlD";
  action=function()

  local s=mf.clip(0)
  s = mf.replace(s, '"', '')
  s = mf.trim(s)
  local sDisk = mf.fsplit(s, 1)  -- FSPLIT_DISK = 1
  local sPath = mf.fsplit(s, 2)  -- FSPLIT_PATH = 2
  local sName = mf.fsplit(s, 4)  -- FSPLIT_NAME = 4
  local sExt  = mf.fsplit(s, 8)  -- FSPLIT_EXT  = 8

  Panel.SetPath(0, sDisk)
  Panel.SetPath(0, sPath, sName..sExt)

  end;
}
