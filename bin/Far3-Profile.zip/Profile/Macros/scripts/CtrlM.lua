Macro {
  area="Shell"; key="CtrlM"; description="Advanced compare"; action = function()

  Keys('F11 M')

  end;
}
