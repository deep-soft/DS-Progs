Macro {
  area="Shell Tree QView Info"; key="`"; flags="EmptyCommandLine"; description="Use ` to toggle panels on/off (with keybar)"; action = function()

Keys('CtrlO')
Far.KeyBar_Show((APanel.Visible or PPanel.Visible) and 1 or 2)

  end;
}

