Macro {
  description="Activate the same folder in the passive panel as in the active panel";
  area="Shell"; key="AltLeft"; flags="NoPluginPanels";
  action=function()

  Panel.SetPath(1, APanel.Path)
  Panel.SetPosIdx(1, APanel.CurPos)

  end;
}

Macro {
  description="Activate the same folder in the passive panel as in the active panel";
  area="Shell"; key="AltRight"; flags="NoPluginPanels";
  action=function()

  Panel.SetPath(1, APanel.Path)
  Panel.SetPosIdx(1, APanel.CurPos)

  end;
}
