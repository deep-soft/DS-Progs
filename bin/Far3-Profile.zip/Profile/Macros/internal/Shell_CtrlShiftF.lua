Macro {
  description="";
  area="Shell"; key="CtrlShiftF";
  flags="";
  code="Keys(\"RCtrlF BS RCtrlIns Esc\")";
}
