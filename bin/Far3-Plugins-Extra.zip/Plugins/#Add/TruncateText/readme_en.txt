Plug-in "Truncate Text" for Far Manager 2.0
*******************************************

Plugin for Far Manager's editor, that allows you to remove extra spaces
(including tabs) at the end of lines and blank lines at end of file.

Original idea: plugin TrancateTxt for Far 1.7 by Alexei Firsakov.

Install:
  Unpack the archive to the Far plugins directory (...Far\Plugins).

Warning:
  This plugin is provided "as is". The author is not responsible for the
  consequences of use of this software.

Artem Senichev (artemsen@gmail.com)
               http://code.google.com/p/farplugs
