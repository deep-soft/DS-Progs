local Filters = {}

function Filters.ID()
  return "C061BF35-247C-48CA-BD77-5885125C5229"
end

function Filters.Installed()
  return Plugin.Exist(Filters.ID())
end

function Filters.Execute(ID)
  return Plugin.Call(Filters.ID(), "execute", ID)
end

function Filters.ExecuteByName(Name)
  return Plugin.Call(Filters.ID(), "execute-by-name", Name)
end

Macro
{
  description = "Filters: execute filter (autoselect)";
  area = "Editor";
  key = "F5";
  condition = function(key, data)
    return Filters.Installed();
  end;
  action = function()
    return Filters.Execute("auto");
  end;
}
