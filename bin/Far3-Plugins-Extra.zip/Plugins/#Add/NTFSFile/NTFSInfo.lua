local NTFSInfo = '1D1BA1CB-3A05-4F4B-91B3-F8E71A55420E'
local NTFSMenu = 'B0476A89-0D49-4D3D-82ED-4F011B859572'
Macro {
  area = "Shell";
  key = "CtrlShiftN";
  description = "NTFS menu";
  condition = function() return Plugin.Exist(NTFSInfo) end;
  action = function() Plugin.Menu(NTFSInfo, NTFSMenu) end;
}
Macro {
  area = "Shell Viewer";
  key = "CtrlShiftV";
  description = "File version";
  condition = function() return Plugin.Exist(NTFSInfo) end;
  action = function() Plugin.Call(NTFSInfo, "Menu", "version") end;
}
Macro {
  area = "Shell Viewer";
  key = "CtrlShiftC";
  description = "File checksums";
  condition = function() return Plugin.Exist(NTFSInfo) end;
  action = function() Plugin.Call(NTFSInfo, "Menu", "content") end;
}
Macro {
  area = "Shell";
  key = "CtrlShiftF";
  description = "File metadata";
  condition = function() return Plugin.Exist(NTFSInfo) and Far.IsUserAdmin end;
  action = function() Plugin.Call(NTFSInfo, "Menu", "metadata") end;
}
Macro {
  area = "Shell";
  key = "CtrlShiftZ";
  description = "File compress";
  condition = function() return Plugin.Exist(NTFSInfo) and Far.IsUserAdmin end;
  action = function() Plugin.Call(NTFSInfo, "Menu", "compress") end;
}
Macro {
  area = "Shell";
  key = "CtrlShiftD";
  description = "File defragment";
  condition = function() return Plugin.Exist(NTFSInfo) and Far.IsUserAdmin end;
  action = function() Plugin.Call(NTFSInfo, "Menu", "defrag") end;
}
Macro {
  area = "Shell";
  key = "CtrlShiftP";
  description = "NTFS panel toggle";
  condition = function() return Plugin.Exist(NTFSInfo) and Far.IsUserAdmin end;
  action = function() Plugin.Call(NTFSInfo, "Menu", "panel") end;
}
