
	The calculator of the clipboard in the FAR editor. FREEWARE
        =================================================

    Version 6.03, 24.12.2017 (for FAR 3.00 build 5000 x64 unicode)

The description
--------------------------

This plugin allows to calculate and sum numbers and numerical expressions
within selected area in the built-in editor. The result is placed in Clipboard.


Installation and start
----------------------

Unpack archive in subdirectory ClipCalc of a directory Plugins or 
Plugins\Editor. Restart FAR.

The operating procedure
-----------------------

1) Select numbers and numerical expressions in the built-in editor.
2) Press F11, cause "our" plugin - "Clipboard Calculator".
3) In the opening dialogue modify parameters (if required) and
press Enter. Result of the calculation and addition - in Clipboard.


History
-------

                     Version 6.03,  24.12.2017.

 ! Fixed a mistake in x64-module of ttmath library, which revealed
itself in builds 4xxxx and later (Far 3.0 x64). The error led to
a memory violation exception during calculations. The plugin was
rebuilt with a new (repeared) version of library
ttmath-0.9.4-prerelease-2017.03.12. Besides, the source
codes were added into the distribution. 

                     Version 6.02,  04.10.2015.

 ! Fixed mistakes of output rounding ("expr -r2 0.999" gave "1",
should be "1.00"; "expr 10000*0.1" gave "10000000000.000000",
should be "1000.000000"). Overloaded functions ROUND, FLOOR, CEIL.
Added synonym "~=" for operacion "<>". Added synonyms FACTOR, ORD, AVR,
FIX for functions FACT, ASC, AVG, INT (accordingly). Added functions
TRUNC, ROOT, GAMMA, GAMMA2. In case of mistakes in the expression,
the result is 0.   

                     Version 6.01,  08.03.2015.

 ! Fixed a mistake of rounding output for some values ("expr -r1 4.99"
gave "5", should be "5.0")

                     Version 6.00,  05.10.2014.

 ! The calculator reworked on base of 512-bit arithmetic (ttmath library)

                     Version 5.02,  02.10.2014.

 ! Fixed accuracy losts. Added new functions: aggregate, statistic,
combinatorics and conditional.

                     Version 5.01,  26.07.2013.

 ! Added new functions and constants for using some numerical notations.

                     Version 5.00,  24.05.2013.

 ! Added new operations, functions and constants.

                     Version 4.04,  22.05.2013.

 ! Stopped using NET Framework 3.5.

                     Version 4.03,  14.04.2013.

 ! Fixed delimiting of expressions. When the Tabs/Spaces checkbox is off,
any tabs and spaces within the selected area are ignored. Besides, added
EOLN checkbox for end of line as an expression delimitor. If Tabs/Spaces
and EOLN checkboxes are off simultaneously then the entire selected area
is expected one expression.

                     Version 4.02,  10.02.2013.

 ! Fixed thousand separation when the result is negative. Localized captions fully.

                     Version 4.01,  24.01.2013.

 ! Fixed processing with the empty source decimal separator. In this case
we assume '.' in the capacity of source decimal separator.

-------------------------------------------------------------------------
Best regards,                                            Aleksei Belousov
                                                alex_belousov@hotmail.com

