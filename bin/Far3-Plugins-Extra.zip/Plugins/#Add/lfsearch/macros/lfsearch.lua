------------------------------------------------------------------------------
-- LuaFAR Search --
------------------------------------------------------------------------------

local Guid = "8E11EA75-0303-4374-AC60-D1E38F865449"
local function LFS_Editor(...) Plugin.Call(Guid, "own", "editor", ...) end
local function LFS_Panels(...) Plugin.Call(Guid, "own", "panels", ...) end
local function LFS_Exist() return Plugin.Exist(Guid) end

Macro {
  description="LuaFAR Search: Editor Find";
  area="Editor"; key="F3"; condition=LFS_Exist;
  action = function() LFS_Editor "search" end
}

Macro {
  description="LuaFAR Search: Editor Replace";
  area="Editor"; key="CtrlF3"; condition=LFS_Exist;
  action = function() LFS_Editor "replace" end
}

Macro {
  description="LuaFAR Search: Editor Repeat";
  area="Editor"; key="ShiftF3"; condition=LFS_Exist;
  action = function() LFS_Editor "repeat" end
}

Macro {
  description="LuaFAR Search: Editor Repeat reverse";
  area="Editor"; key="AltF3"; condition=LFS_Exist;
  action = function() LFS_Editor "repeat_rev" end
}

Macro {
  description="LuaFAR Search: Editor search word";
  area="Editor"; key="Alt6"; condition=LFS_Exist;
  action = function() LFS_Editor "searchword" end
}

Macro {
  description="LuaFAR Search: Editor search word reverse";
  area="Editor"; key="Alt5"; condition=LFS_Exist;
  action = function() LFS_Editor "searchword_rev" end
}

Macro {
  description="LuaFAR Search: Editor Multi-line replace";
  area="Editor"; key="CtrlShiftF3"; condition=LFS_Exist;
  action = function() LFS_Editor "mreplace" end
}

Macro {
  description="LuaFAR Search: Panel Find";
  area="Shell QView Tree Info"; key="CtrlShiftF"; condition=LFS_Exist;
  action = function() LFS_Panels "search" end
}

Macro {
  description="LuaFAR Search: Panel Replace";
  area="Shell QView Tree Info"; key="CtrlShiftG"; condition=LFS_Exist;
  action = function() LFS_Panels "replace" end
}

Macro {
  description="LuaFAR Search: Panel Rename";
  area="Shell QView Tree Info"; key="CtrlShiftH"; condition=LFS_Exist;
  action = function() LFS_Panels "rename" end
}
