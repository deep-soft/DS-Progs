-- coding: utf-8

AddCommand("test", "test_lfsearch")

AddToMenu ("e", "9. Self-test", nil, "test_lfsearch")
AddToMenu ("e", ":sep:User scripts")
AddToMenu ("e", "URLs", nil, "scripts/presets", "url")
AddToMenu ("e", "Credit Card numbers", nil, "scripts/presets", "creditcard")
