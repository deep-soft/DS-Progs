 ______________________________________________________________________________
|                                                                              |
|   FRename3 v1.00                    (c) 2014-15 Pepak, http://www.pepak.net  |
|______________________________________________________________________________|

This is a file rename plugin, based on the Jouri Mamev's FRename plugin
(http://plugring.farmanager.com/plugin.php?pid=464). It has been, however,
completely re-implemented and updated to work with modern versions of FAR.
Where it seemed useful, I also added some new functionality.



USAGE
-----

In a panel, select the files you wish to rename and invoke the plugin from
the Plugins Menu (F11). The list of filenames will appear in FAR's editor,
in two columns; the left column represents the original filename, the right
column the desired filename. You can edit this file as much as you want,
using any resources available to you. When you are finished, the plugin will
scan the file for lines in the form '"filename1" "filename2"' and try to
rename the files as to your specifications.

To facilitate this editing process, several hotkeys are available (also
available from plugin menu F11):

  ALT+F1 .... If the cursor is on a line which represents filenames,
              move the cursor to the first character of the target
              filename.
  ALT+F2 .... Mark a vertical block which contains all target filenames.
              You can then e.g. run a Change Case or RESearch plugins
              on this block. Note that the enveloping quotes are also
              selected!



LICENSE
-------

The plugin is released under the Modified (3-clause) BSD License. See
license.txt for details.



BUILDING THE PLUGIN
-------------------

You will need Delphi version at least 2009. Older versions are not supported.
Newer versions should work fine, I tested the build with Delphi XE2 as well
as 2009, and most of the library code has been tested with XE4 too.

Make sure the chosen Delphi's BIN directory is in the PATH, go into the
SOURCE directory and run BUILD. You should get a new FRename3.dll in the BIN
directory.

You can use several command-line options with BUILD. The most important are:

    FAR2 ........ Build the FAR2 version of the plugin.
    FAR3 ........ Build the FAR3 version of the plugin (default).
    X86 ......... Build the 32-bit version of the plugin (default).
    X64 ......... Build the 64-bit version of the plugin.



CONTACT
-------

If you have any questions or want to suggest a new feature, you can do so
either at FAR Manager's forums in my FRename3 thread ( http://forum.farmanager.com/viewtopic.php?f=39&t=9719 ),
my own forums ( http://forum.pepak.net ).
