Plug-in "PEAnalyzer" for Far Manager 3.0
****************************************

The analyzer executables files MS Windows (x86/x64) with built-in disassembler.
Disassembler up to version 3.9 based on the BeaEngine library (http://www.beaengine.org/).

Versions 3.10+ are based on the Capstone library (https://github.com/capstone-engine/capstone).
Also here added support for Arm/Arm64 PE files disassembling.

Install:
  Unpack the archive to the Far plugins directory (...Far\Plugins).

Warning:
  This plugin is provided "as is". The author is not responsible for the
  consequences of use of this software.

Artem Senichev (artemsen@gmail.com)
Vladimir Surguchev (2usen10@gmail.com)
https://sourceforge.net/projects/farplugs/
