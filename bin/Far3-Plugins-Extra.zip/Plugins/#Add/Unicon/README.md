﻿A little program that turns this:

![image](https://user-images.githubusercontent.com/11453922/122759189-93ff3900-d291-11eb-89a9-b1d47aa22ed9.png)

into this:

![image](https://user-images.githubusercontent.com/11453922/122759316-b4c78e80-d291-11eb-87aa-7cdc2979ae28.png)

Usage:

`unicon` - improve the current console window.

`unicon <pid>` - improve the console window of a different conhost process.

unicon.dll can be also used as a plugin for [Far](https://github.com/FarGroup/FarManager).
