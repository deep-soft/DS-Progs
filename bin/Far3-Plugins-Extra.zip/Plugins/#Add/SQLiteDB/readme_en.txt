Plug-in "SQLite DB Browser" for Far Manager 3.0
***********************************************

This plugin allows you to view tables content of SQLite database.

The prefix to invoke the plugin from the command line: "sqlitedb:".

Install:
  Unpack the archive to the Far plugins directory (...Far\Plugins).

Warning:
  This plugin is provided "as is". The author is not responsible for the
  consequences of use of this software.

Artem Senichev (artemsen@gmail.com)
               https://sourceforge.net/projects/farplugs/
