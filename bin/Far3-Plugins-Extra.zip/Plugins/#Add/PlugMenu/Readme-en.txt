PlugMenu v 1.0 for FAR
----------------------

This plugin replaces the standard Plugin Commands menu. It offers several
advanced features: displaying additional information, sorting, filtering
while typing, and the ability to hide unnecessary or rarely used commands.

By default, the dialog only shows plugins available in the current context
(file panel, editor, etc.). Pressing Ctrl-H will show the full list of
plugins. Those that are unavailable in the current context are marked with
a dot at the beginning. Their commands cannot be executed.

All options for displaying extended information are enabled directly in the
dialog using hotkeys (their description is in the help). To start filtering,
type text while holding down the Alt key. By default, the entered text is
searched at the beginning of each word. To filter by substring, type "*" as
the first character.

For Far 2/3, dynamic unloading and loading of plugins is supported, similar
to the "unloadp:" and "pload:" commands. Plugins are unloaded with the
"Ctrl-Del" command. To load a plugin back, enable the mode for showing
unavailable plugins (Ctrl-H); unloaded plugins are marked with "X". The
command to load a plugin is "Ins".