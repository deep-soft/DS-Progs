﻿svcmgr: Manage services FAR plugin

Allow to manage windows services

TODO:
Пока не работает диалог изменения зависимостей сервиса, доделаю когда-нибудь

Спасибо за русский lng файл:
VictorVG @ VikSoft.Ru

© 2013 Andrew Grechkin
	mailto: andrew.grechkin@gmail.com
	jabber: andrew.grechkin@gmail.com

Исходный код:
	https://github.com/andrew-grechkin/main
