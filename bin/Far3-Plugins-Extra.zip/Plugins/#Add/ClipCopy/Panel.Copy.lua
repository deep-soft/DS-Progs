local GUIDclipcopy = "FA871763-7379-4CB4-BDB0-E4EF6FB0B524"
local MacroCopyDsc = "Copy selected file(s) thru clipboard"
local MacroCopyKey = "CtrlShiftF5"
local MacroCopyFlg = "EmptyCommandLine NoPluginPanels NoPluginPPanels"

Macro {
  area="Shell"; key=MacroCopyKey; flags=MacroCopyFlg; description=MacroCopyDsc;
  condition = function()
    return Plugin.Exist(GUIDclipcopy)
       and PPanel.Visible
       and APanel.FilePanel and PPanel.FilePanel
       and APanel.Path ~= PPanel.Path
  end;
  action = function()
    Plugin.Menu(GUIDclipcopy); Keys("1 Tab")
    Plugin.Menu(GUIDclipcopy); Keys("3 Tab")
  end;
}