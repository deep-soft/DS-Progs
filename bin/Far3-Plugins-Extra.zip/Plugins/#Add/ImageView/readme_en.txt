Plug-in "ImageView" for Far Manager 3.0
***************************************

Image viewer based on FreeImage library (http://freeimage.sourceforge.net).

Install:
  Unpack the archive to the Far plugins directory (...Far\Plugins).

Warning:
  This plugin is provided "as is". The author is not responsible for the
  consequences of use of this software.

Artem Senichev (artemsen@gmail.com)
               https://sourceforge.net/projects/farplugs/
