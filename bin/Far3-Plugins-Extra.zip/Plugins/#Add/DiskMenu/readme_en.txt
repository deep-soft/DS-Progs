Plug-in "Disk Menu Editor" for Far Manager 3.0
**********************************************

Plugin that allows you to add links to the disk menu (Alt+F1 / Alt+F2),
such as:
  - Local and network folders;
  - Special folders (My Documents, Desktop, etc.);
  - Folders from registry value;
  - Far's Plug-ins, available via the prefix;
  - Submenu.

Install:
  Unpack the archive to the Far plugins directory (...Far\Plugins).

Warning:
  This plugin is provided "as is". The author is not responsible for the
  consequences of use of this software.

Artem Senichev (artemsen@gmail.com)
              https://sourceforge.net/projects/farplugs/
